import time
import sys
import os
import LoadAnim
import argparse
import subprocess
from pyfiglet import Figlet
from clint.textui import puts, colored, indent