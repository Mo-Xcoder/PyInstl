# PyInstl
A package installer cli for python.
